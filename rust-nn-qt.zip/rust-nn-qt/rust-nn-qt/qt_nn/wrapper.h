#pragma once

// Qt Core headers - Komponen inti Qt untuk pengelolaan objek, string, timer, thread, dan sinkronisasi data
#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QTimer>
#include <QtCore/QVector>
#include <QtCore/QThread>
#include <QtCore/QMutex>

// Qt Widget headers - Digunakan untuk membangun antarmuka pengguna aplikasi klasifikasi tanaman
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QWidget>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QStatusBar>

// QCustomPlot - Digunakan untuk menampilkan grafik visualisasi hasil klasifikasi tanaman berdasarkan fitur:
#include "qcustomplot.h"
