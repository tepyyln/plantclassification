# Neural Network Plant Classification

A Rust-based neural network implementation for plant classification with GUI visualization.

## Features

- Interactive training of neural networks for plant classification
- Real-time visualization of training progress
- Neural network architecture visualization
- Training metrics plotting (accuracy and loss)
- Automatically saves training results as PNG images

## Training Results

The application automatically saves the following plot images to the `result` directory:

- **loss_plot.png**: Shows the training loss over epochs
- **accuracy_plot.png**: Shows the classification accuracy over epochs
- **training_results.png**: A combined view of both loss and accuracy

## How to Run

```bash
cargo run
```

## Usage Instructions

1. Configure the training parameters:
   - **Epochs**: Number of training iterations (default: 1000)
   - **Hidden Neurons**: Size of the hidden layer (default: 64)
   
2. Click the "Start Training" button to begin training

3. During training, you can observe:
   - Real-time accuracy and loss graphs
   - Current prediction for a sample
   - Neural network architecture (optional)
   
4. After training completes:
   - Final accuracy will be displayed
   - Training plots will be saved to the `result` directory
   - The "Saved Training Results" section will appear with links to view the plots

5. Click on the plot links or "Open" buttons to view the saved PNG images

## Dataset

The application uses the Crop Recommendation Dataset in CSV format located in the `csv` directory.

## Requirements

- Rust 2021 edition or later
- Dependencies as listed in Cargo.toml 