use csv::ReaderBuilder;
use ndarray::{Array2, Axis, s};
use ndarray_rand::rand_distr::StandardNormal;
use ndarray_rand::RandomExt;
use std::error::Error;
use std::sync::{Arc, Mutex};
use std::thread;
use eframe;
use plotters::prelude::*;

mod frontend;
use frontend::{NeuralNetworkApp, AppWrapper};

fn sigmoid(x: &Array2<f64>) -> Array2<f64> {
    x.mapv(|v| 1.0 / (1.0 + (-v).exp()))
}

fn sigmoid_derivative(x: &Array2<f64>) -> Array2<f64> {
    x * &(1.0 - x)
}

// Softmax activation function for multi-class classification
fn softmax(x: &Array2<f64>) -> Array2<f64> {
    let max_vals = x.map_axis(Axis(1), |row| row.fold(f64::NEG_INFINITY, |a, &b| a.max(b)));
    let exp_vals = x.outer_iter()
        .zip(max_vals.iter())
        .map(|(row, &max_val)| {
            row.mapv(|v| (v - max_val).exp())
        })
        .collect::<Vec<_>>();
    
    let sum_exp = exp_vals.iter()
        .map(|row| row.sum())
        .collect::<Vec<_>>();
    
    let result = exp_vals.iter()
        .zip(sum_exp.iter())
        .map(|(row, &sum)| {
            row.mapv(|v| v / sum)
        })
        .collect::<Vec<_>>();
    
    let (rows, cols) = x.dim();
    let mut output = Array2::zeros((rows, cols));
    for (i, row) in result.iter().enumerate() {
        output.row_mut(i).assign(row);
    }
    
    output
}

// Cross-entropy loss for multi-class classification
fn cross_entropy_loss(pred: &Array2<f64>, target: &Array2<f64>) -> f64 {
    let eps = 1e-9;
    let pred_clipped = pred.mapv(|v| v.max(eps).min(1.0 - eps));
    let losses = target * &pred_clipped.mapv(|v| v.ln());
    -losses.sum() / target.nrows() as f64
}

fn load_data(path: &str) -> Result<(Array2<f64>, Array2<f64>, Vec<String>), Box<dyn Error>> {
    let mut rdr = ReaderBuilder::new().has_headers(true).from_path(path)?;
    let _headers = rdr.headers()?.clone();

    let mut features: Vec<Vec<f64>> = Vec::new();
    let mut labels: Vec<String> = Vec::new();

    for result in rdr.records() {
        let record = result?;
        let mut row: Vec<f64> = Vec::new();
        for i in 0..record.len() - 1 {
            row.push(record[i].parse()?);
        }
        features.push(row);
        labels.push(record[record.len() - 1].to_string());
    }

    // Get unique labels and sort them for consistent indexing
    let unique_labels: Vec<String> = {
        let mut set = std::collections::BTreeSet::new();
        for label in &labels {
            set.insert(label.clone());
        }
        set.into_iter().collect()
    };
    
    println!("Available classes: {:?}", unique_labels);
    
    // Create one-hot encoded labels for multi-class classification
    let num_classes = unique_labels.len();
    let mut one_hot_labels = Array2::<f64>::zeros((labels.len(), num_classes));
    
    for (i, label) in labels.iter().enumerate() {
        let class_index = unique_labels.iter().position(|l| l == label).unwrap();
        one_hot_labels[[i, class_index]] = 1.0;
    }

    let feature_array = Array2::from_shape_vec((features.len(), features[0].len()), features.concat())?;

    println!(
        "Loaded dataset: {} samples, {} features, {} classes",
        features.len(),
        features[0].len(),
        num_classes
    );

    Ok((feature_array, one_hot_labels, unique_labels))
}

fn train_neural_network(
    app: Arc<Mutex<NeuralNetworkApp>>,
    epochs: usize, 
    hidden_size: usize,
    learning_rate: f64,
    file_path: String
) -> Result<(), Box<dyn Error>> {
    // Check if the CSV file exists first
    if !std::path::Path::new(&file_path).exists() {
        return Err(format!("Dataset file '{}' not found", file_path).into());
    }

    let (x, y_true, class_names) = load_data(&file_path)?;
    let (n_samples, input_size) = x.dim();
    let output_size = class_names.len(); // Number of unique classes
    
    // Update UI with dataset information for architecture visualization
    {
        let mut locked_app = app.lock().unwrap();
        locked_app.set_dataset_info(input_size, output_size);
        locked_app.set_class_names(class_names.clone());
        locked_app.set_total_epochs(epochs);
    }

    // Split data into training (80%) and test (20%) sets
    let test_size = n_samples / 5; // 20% for testing
    let train_size = n_samples - test_size;
    
    // Create indices and shuffle them
    let mut indices: Vec<usize> = (0..n_samples).collect();
    let mut rng = rand::thread_rng();
    use rand::seq::SliceRandom;
    indices.shuffle(&mut rng);
    
    // Create training and test sets
    let mut x_train = Array2::zeros((train_size, input_size));
    let mut y_train = Array2::zeros((train_size, output_size));
    let mut x_test = Array2::zeros((test_size, input_size));
    let mut y_test = Array2::zeros((test_size, output_size));
    
    for (i, &idx) in indices.iter().take(train_size).enumerate() {
        x_train.row_mut(i).assign(&x.row(idx));
        y_train.row_mut(i).assign(&y_true.row(idx));
    }
    
    for (i, &idx) in indices.iter().skip(train_size).take(test_size).enumerate() {
        x_test.row_mut(i).assign(&x.row(idx));
        y_test.row_mut(i).assign(&y_true.row(idx));
    }
    
    println!("Data split: {} training samples, {} test samples", train_size, test_size);

    // Feature normalization - improves accuracy significantly
    let x_train_mean = x_train.mean_axis(Axis(0)).unwrap();
    let x_train_std = {
        let variance = (&x_train - &x_train_mean).mapv(|x| x.powi(2)).mean_axis(Axis(0)).unwrap();
        variance.mapv(|x| x.sqrt().max(1e-8)) // Avoid division by zero
    };
    
    // Normalize training data
    let x_train_normalized = (&x_train - &x_train_mean) / &x_train_std;
    
    // Normalize test data with training statistics
    let x_test_normalized = (&x_test - &x_train_mean) / &x_train_std;
    
    println!("Data normalized to improve training stability");

    // Use a more sophisticated architecture with two hidden layers
    let hidden_size_1 = hidden_size;
    let hidden_size_2 = hidden_size / 2; // Second layer half the size
    
    // Initialize weights with He initialization for better convergence
    let he_init_1 = 2.0 / (input_size as f64).sqrt();
    let he_init_2 = 2.0 / (hidden_size_1 as f64).sqrt();
    let he_init_3 = 2.0 / (hidden_size_2 as f64).sqrt();
    
    let mut w1 = Array2::random_using((input_size, hidden_size_1), StandardNormal, &mut rng) * he_init_1;
    let mut b1: Array2<f64> = Array2::zeros((1, hidden_size_1));
    let mut w2 = Array2::random_using((hidden_size_1, hidden_size_2), StandardNormal, &mut rng) * he_init_2;
    let mut b2: Array2<f64> = Array2::zeros((1, hidden_size_2));
    let mut w3 = Array2::random_using((hidden_size_2, output_size), StandardNormal, &mut rng) * he_init_3;
    let mut b3: Array2<f64> = Array2::zeros((1, output_size));

    // Define update frequency - update more frequently initially, then less often
    let update_frequency = if epochs > 3000 { 10 } else { 2 };

    let mut loss_history: Vec<(f64, f64)> = Vec::new();
    let mut accuracy_history: Vec<(f64, f64)> = Vec::new();
    let mut test_loss_history: Vec<(f64, f64)> = Vec::new();
    let mut test_accuracy_history: Vec<(f64, f64)> = Vec::new();
    let mut predictions_history: Vec<String> = Vec::new();
    
    // For early stopping
    let patience = 500; // Number of epochs to wait for improvement
    let min_delta = 0.0005; // Minimum change to be considered as improvement
    let mut best_accuracy = 0.0;
    let mut no_improvement_count = 0;
    let mut best_weights = (w1.clone(), b1.clone(), w2.clone(), b2.clone(), w3.clone(), b3.clone());

    // Function to evaluate model on test data
    let evaluate_model = |w1: &Array2<f64>, b1: &Array2<f64>, w2: &Array2<f64>, b2: &Array2<f64>, 
                          w3: &Array2<f64>, b3: &Array2<f64>| -> (f64, f64) {
        // Forward pass on test data
        let z1 = x_test_normalized.dot(w1) + b1;
        let a1 = sigmoid(&z1);
        let z2 = a1.dot(w2) + b2;
        let a2 = sigmoid(&z2);
        let z3 = a2.dot(w3) + b3;
        let y_pred = softmax(&z3);
        
        // Calculate test loss
        let test_loss = cross_entropy_loss(&y_pred, &y_test);
        
        // Calculate test accuracy
        let pred_class_indices = y_pred.map_axis(Axis(1), |row| {
            row.iter().enumerate()
                .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
                .map(|(i, _)| i)
                .unwrap() as f64
        });
        
        let true_class_indices = y_test.map_axis(Axis(1), |row| {
            row.iter().enumerate()
                .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
                .map(|(i, _)| i)
                .unwrap() as f64
        });
        
        let correct = pred_class_indices.iter()
            .zip(true_class_indices.iter())
            .filter(|(&a, &b)| (a - b).abs() < 1e-6)
            .count();
            
        let test_accuracy = (correct as f64 / test_size as f64) * 100.0;
        
        (test_loss, test_accuracy)
    };

    // Use a more advanced optimizer with momentum for faster convergence
    let momentum = 0.9;
    let mut vw1: Array2<f64> = Array2::zeros(w1.dim());
    let mut vb1: Array2<f64> = Array2::zeros(b1.dim());
    let mut vw2: Array2<f64> = Array2::zeros(w2.dim());
    let mut vb2: Array2<f64> = Array2::zeros(b2.dim());
    let mut vw3: Array2<f64> = Array2::zeros(w3.dim());
    let mut vb3: Array2<f64> = Array2::zeros(b3.dim());

    for epoch in 0..epochs {
        // Training on training data with the deeper network
        let z1 = x_train_normalized.dot(&w1) + &b1;
        let a1 = sigmoid(&z1);
        let z2 = a1.dot(&w2) + &b2;
        let a2 = sigmoid(&z2);
        let z3 = a2.dot(&w3) + &b3;
        let y_pred = softmax(&z3);

        let loss = cross_entropy_loss(&y_pred, &y_train);

        // Backpropagation with the deeper network
        let dz3 = &y_pred - &y_train;
        let dw3 = a2.t().dot(&dz3) / train_size as f64;
        let db3 = dz3.sum_axis(Axis(0)) / train_size as f64;

        let da2 = dz3.dot(&w3.t());
        let dz2 = da2 * sigmoid_derivative(&a2);
        let dw2 = a1.t().dot(&dz2) / train_size as f64;
        let db2 = dz2.sum_axis(Axis(0)) / train_size as f64;
        
        let da1 = dz2.dot(&w2.t());
        let dz1 = da1 * sigmoid_derivative(&a1);
        let dw1 = x_train_normalized.t().dot(&dz1) / train_size as f64;
        let db1 = dz1.sum_axis(Axis(0)) / train_size as f64;

        // Apply learning rate decay for better convergence in later epochs
        let effective_lr = learning_rate / (1.0 + 0.0001 * epoch as f64);
        
        // Update with momentum
        vw3 = &(vw3 * momentum) - &(dw3 * effective_lr);
        vb3 = &(vb3 * momentum) - &(db3 * effective_lr);
        vw2 = &(vw2 * momentum) - &(dw2 * effective_lr);
        vb2 = &(vb2 * momentum) - &(db2 * effective_lr);
        vw1 = &(vw1 * momentum) - &(dw1 * effective_lr);
        vb1 = &(vb1 * momentum) - &(db1 * effective_lr);
        
        w3 = &w3 + &vw3;
        b3 = &b3 + &vb3;
        w2 = &w2 + &vw2;
        b2 = &b2 + &vb2;
        w1 = &w1 + &vw1;
        b1 = &b1 + &vb1;

        // Calculate accuracy for multi-class classification on training data
        let pred_class_indices = y_pred.map_axis(Axis(1), |row| {
            row.iter().enumerate()
                .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
                .map(|(i, _)| i)
                .unwrap() as f64
        });
        
        let true_class_indices = y_train.map_axis(Axis(1), |row| {
            row.iter().enumerate()
                .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
                .map(|(i, _)| i)
                .unwrap() as f64
        });
        
        let correct = pred_class_indices.iter()
            .zip(true_class_indices.iter())
            .filter(|(&a, &b)| (a - b).abs() < 1e-6)
            .count();
            
        let accuracy = (correct as f64 / train_size as f64) * 100.0;
        
        // Evaluate on test data periodically to avoid slowing down training
        if epoch % update_frequency == 0 || epoch == 0 || epoch == epochs - 1 {
            let (test_loss, test_accuracy) = evaluate_model(&w1, &b1, &w2, &b2, &w3, &b3);
            test_loss_history.push((epoch as f64, test_loss));
            test_accuracy_history.push((epoch as f64, test_accuracy));
            
            // Update UI with test metrics
            app.lock().unwrap().update_test_metrics(epoch, test_loss, test_accuracy);
            
            println!("Test - Epoch {}: Loss = {:.4}, Accuracy = {:.2}%", epoch, test_loss, test_accuracy);
        }
        
        // Early stopping check
        if accuracy > best_accuracy + min_delta {
            best_accuracy = accuracy;
            no_improvement_count = 0;
            best_weights = (w1.clone(), b1.clone(), w2.clone(), b2.clone(), w3.clone(), b3.clone());
        } else {
            no_improvement_count += 1;
        }
        
        // Stop if no improvement for 'patience' epochs and accuracy is already good
        if no_improvement_count >= patience && accuracy > 92.0 {
            // Restore best weights
            w1 = best_weights.0;
            b1 = best_weights.1;
            w2 = best_weights.2;
            b2 = best_weights.3;
            w3 = best_weights.4;
            b3 = best_weights.5;
            
            println!("Early stopping at epoch {} with accuracy {:.2}%", epoch, best_accuracy);
            
            // Evaluate on test data one last time with best weights
            let (test_loss, test_accuracy) = evaluate_model(&w1, &b1, &w2, &b2, &w3, &b3);
            test_loss_history.push((epoch as f64, test_loss));
            test_accuracy_history.push((epoch as f64, test_accuracy));
            
            // Update UI with the final status before breaking
            if let Some(best_class_idx) = get_prediction_deep(&x_train_normalized, &w1, &b1, &w2, &b2, &w3, &b3, 0) {
                let predicted_label = class_names[best_class_idx].clone();
                app.lock().unwrap().update_progress_with_prediction(epoch, loss, best_accuracy, predicted_label.clone());
                predictions_history.push(predicted_label);
            }
            
            // Add the final point to histories
            loss_history.push((epoch as f64, loss));
            accuracy_history.push((epoch as f64, best_accuracy));
            
            break;
        }

        // Find the predicted label for the first sample
        if epoch % update_frequency == 0 || epoch == 0 || epoch == epochs - 1 {
            if let Some(best_class_idx) = get_prediction_deep(&x_train_normalized, &w1, &b1, &w2, &b2, &w3, &b3, 0) {
                // Get the predicted class name
                let predicted_label = class_names[best_class_idx].clone();
                predictions_history.push(predicted_label.clone());
                
                // Update UI with progress and predictions
                app.lock().unwrap().update_progress_with_prediction(epoch, loss, accuracy, predicted_label);
            }
        }

        // Periodically print to console as well
        if epoch % 100 == 0 || epoch == epochs - 1 {
            println!("Train - Epoch {}: Loss = {:.4}, Accuracy = {:.2}%", epoch, loss, accuracy);
        }
        
        // Small sleep to keep UI responsive - less frequent for long training
        if epoch % 10 == 0 {
            std::thread::sleep(std::time::Duration::from_millis(1));
        }

        loss_history.push((epoch as f64, loss));
        accuracy_history.push((epoch as f64, accuracy));
    }

    // Final evaluation on test data
    let (final_test_loss, final_test_accuracy) = evaluate_model(&w1, &b1, &w2, &b2, &w3, &b3);
    println!("Final test accuracy: {:.2}%", final_test_accuracy);
    
    // Make sure we have the final test point in our history
    if let Some(&(last_epoch, _)) = loss_history.last() {
        if test_loss_history.last().map(|&(e, _)| e) != Some(last_epoch) {
            test_loss_history.push((last_epoch, final_test_loss));
            test_accuracy_history.push((last_epoch, final_test_accuracy));
        }
    }

    // Get final predictions for display
    let z1 = x_train_normalized.dot(&w1) + &b1;
    let a1 = sigmoid(&z1);
    let z2 = a1.dot(&w2) + &b2;
    let a2 = sigmoid(&z2);
    let z3 = a2.dot(&w3) + &b3;
    let y_pred = softmax(&z3);

    // Find the predicted label for the first sample
    let first_sample_pred = y_pred.row(0).to_owned();
    let best_class_idx = first_sample_pred.iter().enumerate()
        .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
        .map(|(idx, _)| idx)
        .unwrap();
    
    // Get the predicted class name
    let predicted_label = class_names[best_class_idx].clone();

    // Calculate final accuracy
    let pred_class_indices = y_pred.map_axis(Axis(1), |row| {
        row.iter().enumerate()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
            .map(|(i, _)| i)
            .unwrap() as f64
    });
    
    let true_class_indices = y_train.map_axis(Axis(1), |row| {
        row.iter().enumerate()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
            .map(|(i, _)| i)
            .unwrap() as f64
    });
    
    let correct = pred_class_indices.iter()
        .zip(true_class_indices.iter())
        .filter(|(&a, &b)| (a - b).abs() < 1e-6)
        .count();
        
    let accuracy = (correct as f64 / train_size as f64) * 100.0;
    
    println!("Final training accuracy: {:.2}%", accuracy);
    println!("Final test accuracy: {:.2}%", final_test_accuracy);

    // Mark training as completed with the final prediction
    app.lock().unwrap().training_completed_with_prediction(accuracy, predicted_label);

    // Save training plots with test data
    save_training_plots(
        &loss_history, 
        &accuracy_history, 
        &class_names, 
        &predictions_history,
        &test_loss_history,
        &test_accuracy_history
    )?;

    Ok(())
}

// Helper function to get prediction for a sample in the deeper network
fn get_prediction_deep(x: &Array2<f64>, w1: &Array2<f64>, b1: &Array2<f64>, w2: &Array2<f64>, b2: &Array2<f64>, w3: &Array2<f64>, b3: &Array2<f64>, sample_idx: usize) -> Option<usize> {
    if sample_idx >= x.nrows() {
        return None;
    }
    
    // Forward pass for a single sample
    let x_sample = x.slice(s![sample_idx..sample_idx+1, ..]);
    let z1 = x_sample.dot(w1) + b1;
    let a1 = sigmoid(&z1);
    let z2 = a1.dot(w2) + b2;
    let a2 = sigmoid(&z2);
    let z3 = a2.dot(w3) + b3;
    let y_pred = softmax(&z3);
    
    // Get the predicted class index
    y_pred.row(0).iter().enumerate()
        .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
        .map(|(idx, _)| idx)
}

fn save_training_plots(
    loss_history: &[(f64, f64)], 
    accuracy_history: &[(f64, f64)], 
    class_names: &[String], 
    predictions: &[String],
    test_loss_history: &[(f64, f64)],
    test_accuracy_history: &[(f64, f64)]
) -> Result<(), Box<dyn Error>> {
    // Create result directory if it doesn't exist
    std::fs::create_dir_all("result")?;

    // Save dedicated test loss and accuracy plots
    if !test_loss_history.is_empty() && !test_accuracy_history.is_empty() {
        // Save test metrics plot
        let root = BitMapBackend::new("result/test_metrics.png", (1000, 800)).into_drawing_area();
        root.fill(&WHITE)?;
        
        let max_epoch = if test_loss_history.is_empty() {
            test_accuracy_history.last().map(|&(epoch, _)| epoch).unwrap_or(0.0)
        } else if test_accuracy_history.is_empty() {
            test_loss_history.last().map(|&(epoch, _)| epoch).unwrap_or(0.0)
        } else {
            let loss_max = test_loss_history.last().map(|&(epoch, _)| epoch).unwrap_or(0.0);
            let acc_max = test_accuracy_history.last().map(|&(epoch, _)| epoch).unwrap_or(0.0);
            if loss_max > acc_max { loss_max } else { acc_max }
        };
            
        let (upper, lower) = root.split_vertically(400);
        
        // Test Loss chart (upper)
        {
            let min_loss: f64 = test_loss_history.iter()
                .map(|&(_, loss)| loss)
                .fold(f64::INFINITY, |a, b| if a < b { a } else { b });
            let max_loss: f64 = test_loss_history.iter()
                .map(|&(_, loss)| loss)
                .fold(0.0, |a, b| if a > b { a } else { b });
            
            let mut chart = ChartBuilder::on(&upper)
                .caption("Test Loss Results (Decimal Format)", ("sans-serif", 30).into_font())
                .margin(10)
                .x_label_area_size(40)
                .y_label_area_size(60)
                .build_cartesian_2d(0.0..max_epoch, min_loss..max_loss * 1.1)?;

            chart.configure_mesh()
                .x_desc("Epochs")
                .y_desc("Loss (Cross-Entropy)")
                .y_label_formatter(&|v: &f64| format!("{:.5}", v)) // Show 5 decimal places
                .draw()?;

            chart.draw_series(LineSeries::new(
                test_loss_history.iter().map(|&(epoch, loss)| (epoch, loss)),
                &RED,
            ))?
            .label("Test Loss")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RED));
            
            // Mark final test loss value
            if let Some(&(final_epoch, final_loss)) = test_loss_history.last() {
                chart.draw_series(PointSeries::of_element(
                    vec![(final_epoch, final_loss)],
                    5,
                    &RED,
                    &|c, s, st| {
                        EmptyElement::at(c) + Circle::new((0, 0), s, st.filled())
                    },
                ))?;
                
                chart.draw_series(std::iter::once(
                    Text::new(
                        format!("Final: {:.5}", final_loss),
                        (final_epoch, final_loss),
                        ("sans-serif", 15).into_font(),
                    )
                ))?;
            }

            chart.configure_series_labels()
                .background_style(&WHITE.mix(0.8))
                .border_style(&BLACK)
                .draw()?;
        }
        
        // Test Accuracy chart (lower)
        {
            let mut chart = ChartBuilder::on(&lower)
                .caption("Test Accuracy Results (%)", ("sans-serif", 30).into_font())
                .margin(10)
                .x_label_area_size(40)
                .y_label_area_size(60)
                .build_cartesian_2d(0.0..max_epoch, 0.0..100.0)?;

            chart.configure_mesh()
                .x_desc("Epochs")
                .y_desc("Accuracy (%)")
                .y_label_formatter(&|v: &f64| format!("{:.2}%", v)) // Show percentage
                .draw()?;

            chart.draw_series(LineSeries::new(
                test_accuracy_history.iter().map(|&(epoch, acc)| (epoch, acc)),
                &GREEN,
            ))?
            .label("Test Accuracy")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &GREEN));
            
            // Add target lines
            chart.draw_series(LineSeries::new(
                vec![(0.0, 95.0), (max_epoch, 95.0)],
                &RGBColor(50, 200, 50).mix(0.3),
            ))?
            .label("Excellent (95%)")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(50, 200, 50).mix(0.5)));
            
            chart.draw_series(LineSeries::new(
                vec![(0.0, 90.0), (max_epoch, 90.0)],
                &RGBColor(200, 200, 50).mix(0.3),
            ))?
            .label("Very Good (90%)")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(200, 200, 50).mix(0.5)));
            
            // Mark final accuracy value
            if let Some(&(final_epoch, final_acc)) = test_accuracy_history.last() {
                chart.draw_series(PointSeries::of_element(
                    vec![(final_epoch, final_acc)],
                    5,
                    &GREEN,
                    &|c, s, st| {
                        EmptyElement::at(c) + Circle::new((0, 0), s, st.filled())
                    },
                ))?;
                
                // Add a text label with performance rating
                let rating = if final_acc >= 95.0 {
                    "Excellent"
                } else if final_acc >= 90.0 {
                    "Very Good"
                } else if final_acc >= 85.0 {
                    "Good"
                } else if final_acc >= 75.0 {
                    "Fair"
                } else {
                    "Needs Improvement"
                };
                
                chart.draw_series(std::iter::once(
                    Text::new(
                        format!("Final: {:.2}% ({})", final_acc, rating),
                        (final_epoch, final_acc),
                        ("sans-serif", 15).into_font(),
                    )
                ))?;
            }

            chart.configure_series_labels()
                .background_style(&WHITE.mix(0.8))
                .border_style(&BLACK)
                .draw()?;
        }
        
        root.present()?;
        println!("Test metrics plot saved to result/test_metrics.png");
    }

    // Save loss plot with enhanced design
    {
        let root = BitMapBackend::new("result/loss_plot.png", (800, 600)).into_drawing_area();
        root.fill(&WHITE)?;
        
        let max_epoch = loss_history.last().map(|&(epoch, _)| epoch).unwrap_or(0.0);
        let min_loss: f64 = loss_history.iter()
            .chain(test_loss_history.iter())
            .map(|&(_, loss)| loss)
            .fold(f64::INFINITY, |a, b| if a < b { a } else { b });
        let max_loss: f64 = loss_history.iter()
            .chain(test_loss_history.iter())
            .map(|&(_, loss)| loss)
            .fold(0.0, |a, b| if a > b { a } else { b });
        
        let mut chart = ChartBuilder::on(&root)
            .caption("Training & Test Loss Over Time", ("sans-serif", 30).into_font())
            .margin(10)
            .x_label_area_size(40)
            .y_label_area_size(60)
            .build_cartesian_2d(0.0..max_epoch, min_loss..max_loss * 1.1)?;

        chart.configure_mesh()
            .x_desc("Epochs")
            .y_desc("Loss (Cross-Entropy)")
            .axis_desc_style(("sans-serif", 15))
            .draw()?;

        // Draw a smoother line by using a moving average
        let window_size = (loss_history.len() / 100).max(1).min(10);
        let smooth_loss: Vec<(f64, f64)> = if window_size > 1 && loss_history.len() > window_size * 2 {
            loss_history.windows(window_size)
                .enumerate()
                .map(|(_i, window)| {
                    let epoch = window[window_size/2].0;
                    let avg_loss = window.iter().map(|&(_, loss)| loss).sum::<f64>() / window_size as f64;
                    (epoch, avg_loss)
                })
                .collect()
        } else {
            loss_history.to_vec()
        };
        
        // Draw original loss as thin line
        chart.draw_series(LineSeries::new(
            loss_history.iter().map(|&(epoch, loss)| (epoch, loss)),
            &RGBColor(200, 200, 200).mix(0.5),
        ))?;
        
        // Draw smoothed loss as thicker line
        chart.draw_series(LineSeries::new(
            smooth_loss.iter().map(|&(epoch, loss)| (epoch, loss)),
            &RED,
        ))?
        .label("Training Loss")
        .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RED));

        // Draw test loss
        if !test_loss_history.is_empty() {
            chart.draw_series(LineSeries::new(
                test_loss_history.iter().map(|&(epoch, loss)| (epoch, loss)),
                &RGBColor(220, 100, 100),
            ))?
            .label("Test Loss")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(220, 100, 100)));
            
            // Add a marker for the final test loss
            if let Some(&(final_epoch, final_loss)) = test_loss_history.last() {
                chart.draw_series(PointSeries::of_element(
                    vec![(final_epoch, final_loss)],
                    5,
                    &RGBColor(220, 100, 100),
                    &|c, s, st| {
                        EmptyElement::at(c) + Circle::new((0, 0), s, st.filled())
                    },
                ))?;
                
                // Add a text label with decimal formatting
                chart.draw_series(std::iter::once(
                    Text::new(
                        format!("Test: {:.5}", final_loss),
                        (final_epoch, final_loss * 1.05),
                        ("sans-serif", 15).into_font(),
                    )
                ))?;
            }
        }

        // Mark final loss value
        if let Some(&(final_epoch, final_loss)) = loss_history.last() {
            // Add a marker for the final loss
            chart.draw_series(PointSeries::of_element(
                vec![(final_epoch, final_loss)],
                5,
                &RED,
                &|c, s, st| {
                    EmptyElement::at(c) + Circle::new((0, 0), s, st.filled())
                },
            ))?;
            
            // Add a text label
            chart.draw_series(std::iter::once(
                Text::new(
                    format!("Train: {:.4}", final_loss),
                    (final_epoch, final_loss),
                    ("sans-serif", 15).into_font(),
                )
            ))?;
        }

        chart.configure_series_labels()
            .background_style(&WHITE.mix(0.8))
            .border_style(&BLACK)
            .draw()?;

        root.present()?;
        println!("Loss plot saved to result/loss_plot.png");
    }

    // Save enhanced accuracy plot
    {
        let root = BitMapBackend::new("result/accuracy_plot.png", (800, 600)).into_drawing_area();
        root.fill(&WHITE)?;
        
        let max_epoch = accuracy_history.last().map(|&(epoch, _)| epoch).unwrap_or(0.0);
        
        let mut chart = ChartBuilder::on(&root)
            .caption("Training & Test Accuracy Over Time", ("sans-serif", 30).into_font())
            .margin(10)
            .x_label_area_size(40)
            .y_label_area_size(60)
            .build_cartesian_2d(0.0..max_epoch, 0.0..100.0)?;

        chart.configure_mesh()
            .x_desc("Epochs")
            .y_desc("Accuracy (%)")
            .axis_desc_style(("sans-serif", 15))
            .draw()?;

        // Draw a smoother line by using a moving average
        let window_size = (accuracy_history.len() / 100).max(1).min(10);
        let smooth_acc: Vec<(f64, f64)> = if window_size > 1 && accuracy_history.len() > window_size * 2 {
            accuracy_history.windows(window_size)
                .enumerate()
                .map(|(_i, window)| {
                    let epoch = window[window_size/2].0;
                    let avg_acc = window.iter().map(|&(_, acc)| acc).sum::<f64>() / window_size as f64;
                    (epoch, avg_acc)
                })
                .collect()
        } else {
            accuracy_history.to_vec()
        };
        
        // Draw original accuracy as thin line
        chart.draw_series(LineSeries::new(
            accuracy_history.iter().map(|&(epoch, acc)| (epoch, acc)),
            &RGBColor(200, 200, 200).mix(0.5),
        ))?;
        
        // Draw smoothed accuracy as thicker line
        chart.draw_series(LineSeries::new(
            smooth_acc.iter().map(|&(epoch, acc)| (epoch, acc)),
            &GREEN,
        ))?
        .label("Training Accuracy")
        .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &GREEN));

        // Draw test accuracy
        if !test_accuracy_history.is_empty() {
            chart.draw_series(LineSeries::new(
                test_accuracy_history.iter().map(|&(epoch, acc)| (epoch, acc)),
                &RGBColor(100, 220, 100),
            ))?
            .label("Test Accuracy")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(100, 220, 100)));
            
            // Add a marker for the final test accuracy
            if let Some(&(final_epoch, final_acc)) = test_accuracy_history.last() {
                chart.draw_series(PointSeries::of_element(
                    vec![(final_epoch, final_acc)],
                    5,
                    &RGBColor(100, 220, 100),
                    &|c, s, st| {
                        EmptyElement::at(c) + Circle::new((0, 0), s, st.filled())
                    },
                ))?;
                
                // Add a text label with performance rating
                let rating = if final_acc >= 95.0 {
                    "Excellent"
                } else if final_acc >= 90.0 {
                    "Very Good"
                } else if final_acc >= 85.0 {
                    "Good"
                } else {
                    "Needs improvement"
                };
                
                chart.draw_series(std::iter::once(
                    Text::new(
                        format!("Test: {:.2}% ({})", final_acc, rating),
                        (final_epoch, final_acc + 3.0),
                        ("sans-serif", 15).into_font(),
                    )
                ))?;
            }
        }

        // Add target lines
        chart.draw_series(LineSeries::new(
            vec![(0.0, 90.0), (max_epoch, 90.0)],
            &RGBColor(50, 200, 50).mix(0.3),
        ))?
        .label("Excellent (90%)")
        .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(50, 200, 50).mix(0.5)));
        
        chart.draw_series(LineSeries::new(
            vec![(0.0, 75.0), (max_epoch, 75.0)],
            &RGBColor(200, 200, 50).mix(0.3),
        ))?
        .label("Good (75%)")
        .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(200, 200, 50).mix(0.5)));

        // Mark final accuracy value
        if let Some(&(final_epoch, final_acc)) = accuracy_history.last() {
            // Add a marker for the final accuracy
            chart.draw_series(PointSeries::of_element(
                vec![(final_epoch, final_acc)],
                5,
                &GREEN,
                &|c, s, st| {
                    EmptyElement::at(c) + Circle::new((0, 0), s, st.filled())
                },
            ))?;
            
            // Add a text label with performance rating
            let rating = if final_acc >= 90.0 {
                "Good"
            } else {
                "Needs improvement"
            };
            
            chart.draw_series(std::iter::once(
                Text::new(
                    format!("Train: {:.2}% ({})", final_acc, rating),
                    (final_epoch, final_acc),
                    ("sans-serif", 15).into_font(),
                )
            ))?;
        }

        chart.configure_series_labels()
            .background_style(&WHITE.mix(0.8))
            .border_style(&BLACK)
            .draw()?;

        root.present()?;
        println!("Accuracy plot saved to result/accuracy_plot.png");
    }

    // Create a combined plot
    {
        let root = BitMapBackend::new("result/training_results.png", (1000, 800)).into_drawing_area();
        
        root.fill(&WHITE)?;
        
        let max_epoch = accuracy_history.last().map(|&(epoch, _)| epoch).unwrap_or(0.0);
        let (upper, lower) = root.split_vertically(400);
        
        // Loss chart (upper)
        {
            let min_loss = loss_history.iter()
                .chain(test_loss_history.iter())
                .map(|&(_, loss)| loss)
                .fold(f64::INFINITY, |a: f64, b| a.min(b));
            let max_loss = loss_history.iter()
                .chain(test_loss_history.iter())
                .map(|&(_, loss)| loss)
                .fold(0.0, |a: f64, b| a.max(b));
            
            let mut chart = ChartBuilder::on(&upper)
                .caption("Training & Test Loss", ("sans-serif", 30).into_font())
                .margin(10)
                .x_label_area_size(30)
                .y_label_area_size(60)
                .build_cartesian_2d(0.0..max_epoch, min_loss..max_loss * 1.1)?;

            chart.configure_mesh()
                .x_labels(20)
                .y_desc("Loss")
                .x_desc("Epochs")
                .axis_desc_style(("sans-serif", 15))
                .draw()?;

            chart.draw_series(LineSeries::new(
                loss_history.iter().map(|&(epoch, loss)| (epoch, loss)),
                &RED,
            ))?
            .label("Training Loss")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RED));
            
            // Add test loss to combined plot
            if !test_loss_history.is_empty() {
                chart.draw_series(LineSeries::new(
                    test_loss_history.iter().map(|&(epoch, loss)| (epoch, loss)),
                    &RGBColor(220, 100, 100),
                ))?
                .label("Test Loss")
                .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(220, 100, 100)));
            }

            chart.configure_series_labels()
                .background_style(&WHITE.mix(0.8))
                .border_style(&BLACK)
                .draw()?;
        }
        
        // Accuracy chart (lower)
        {
            let mut chart = ChartBuilder::on(&lower)
                .caption("Training & Test Accuracy", ("sans-serif", 30).into_font())
                .margin(10)
                .x_label_area_size(30)
                .y_label_area_size(60)
                .build_cartesian_2d(0.0..max_epoch, 0.0..100.0)?;

            chart.configure_mesh()
                .x_labels(20)
                .y_desc("Accuracy (%)")
                .x_desc("Epochs")
                .axis_desc_style(("sans-serif", 15))
                .draw()?;

            chart.draw_series(LineSeries::new(
                accuracy_history.iter().map(|&(epoch, acc)| (epoch, acc)),
                &GREEN,
            ))?
            .label("Training Accuracy")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &GREEN));
            
            // Add test accuracy to combined plot
            if !test_accuracy_history.is_empty() {
                chart.draw_series(LineSeries::new(
                    test_accuracy_history.iter().map(|&(epoch, acc)| (epoch, acc)),
                    &RGBColor(100, 220, 100),
                ))?
                .label("Test Accuracy")
                .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(100, 220, 100)));
            }
            
            // Add target lines for accuracy thresholds
            chart.draw_series(LineSeries::new(
                vec![(0.0, 90.0), (max_epoch, 90.0)],
                &RGBColor(50, 200, 50).mix(0.3),
            ))?
            .label("Excellent (90%)")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(50, 200, 50).mix(0.5)));
            
            chart.draw_series(LineSeries::new(
                vec![(0.0, 75.0), (max_epoch, 75.0)],
                &RGBColor(200, 200, 50).mix(0.3),
            ))?
            .label("Good (75%)")
            .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RGBColor(200, 200, 50).mix(0.5)));

            chart.configure_series_labels()
                .background_style(&WHITE.mix(0.8))
                .border_style(&BLACK)
                .draw()?;
        }
        
        root.present()?;
        println!("Combined training results saved to result/training_results.png");
    }

    // Keep the classification results plot
    {
        let root = BitMapBackend::new("result/classification_results.png", (800, 600)).into_drawing_area();
        root.fill(&WHITE)?;
        
        let max_epoch = accuracy_history.last().map(|&(epoch, _)| epoch).unwrap_or(0.0);
        
        // If we don't have enough data, skip this plot
        if predictions.is_empty() || accuracy_history.is_empty() {
            return Ok(());
        }
        
        let mut chart = ChartBuilder::on(&root)
            .caption("Plant Classification Results", ("sans-serif", 30).into_font())
            .margin(10)
            .x_label_area_size(40)
            .y_label_area_size(60)
            .build_cartesian_2d(0.0..max_epoch, 0.0..class_names.len() as f64)?;

        chart.configure_mesh()
            .x_desc("Epochs")
            .y_desc("Predicted Class")
            .y_labels(class_names.len())
            .y_label_formatter(&|y: &f64| {
                let idx = *y as usize;
                if idx < class_names.len() {
                    class_names[idx].clone()
                } else {
                    "Unknown".to_string()
                }
            })
            .axis_desc_style(("sans-serif", 15))
            .draw()?;

        // Create points for each prediction
        let mut class_points: Vec<(f64, f64)> = Vec::new();
        
        // Only use a subset of predictions to avoid overcrowding
        let step = (predictions.len() / 30).max(1);
        
        for i in 0..predictions.len().min(accuracy_history.len()) {
            if i % step != 0 && i != predictions.len() - 1 {
                continue;
            }
            
            let epoch = accuracy_history[i].0;
            if let Some(class_idx) = class_names.iter().position(|name| name == &predictions[i]) {
                class_points.push((epoch, class_idx as f64 + 0.5));
            }
        }
        
        // Draw points for predictions
        chart.draw_series(
            class_points.iter().map(|&(x, y)| {
                let idx = (y - 0.5) as usize;
                let color = if idx < class_names.len() {
                    // Use different colors for different classes
                    match idx % 7 {
                        0 => &RED,
                        1 => &GREEN,
                        2 => &BLUE,
                        3 => &YELLOW,
                        4 => &CYAN,
                        5 => &MAGENTA,
                        _ => &BLACK,
                    }
                } else {
                    &BLACK
                };
                
                Circle::new((x, y), 5, color.filled())
            })
        )?;
        
        // Draw class distribution summary at the end of the plot
        let mut class_counts = std::collections::HashMap::new();
        for prediction in predictions {
            *class_counts.entry(prediction).or_insert(0) += 1;
        }
        
        // Create and store the legend items before using them
        struct LegendItem<'a> {
            name: String,
            percentage: f64,
            color: &'a RGBColor,
        }
        
        let mut legend_items: Vec<LegendItem> = Vec::new();
        for (name, count) in class_counts.iter() {
            let percentage = (*count as f64 / predictions.len() as f64) * 100.0;
            if let Some(idx) = class_names.iter().position(|n| n == *name) {
                let color = match idx % 7 {
                    0 => &RED,
                    1 => &GREEN,
                    2 => &BLUE,
                    3 => &YELLOW,
                    4 => &CYAN,
                    5 => &MAGENTA,
                    _ => &BLACK,
                };
                
                legend_items.push(LegendItem {
                    name: name.to_string(),
                    percentage,
                    color,
                });
            }
        }
        
        // Sort by frequency
        legend_items.sort_by(|a, b| b.percentage.partial_cmp(&a.percentage).unwrap());
        
        // First, create and draw a series for each legend item
        for (i, item) in legend_items.iter().enumerate() {
            // Create marker at legend position
            chart.draw_series(std::iter::once(
                EmptyElement::at((max_epoch * 0.75, i as f64 + 0.5)) + 
                    Circle::new((0, 0), 5, item.color.filled())
            ))?;
        }
        
        // Then configure the legend separately
        chart.configure_series_labels()
            .background_style(&WHITE.mix(0.8))
            .border_style(&BLACK)
            .position(SeriesLabelPosition::UpperRight)
            .draw()?;
            
        // Add text labels manually since we can't use the legend directly
        for (i, item) in legend_items.iter().enumerate() {
            chart.draw_series(std::iter::once(
                Text::new(
                    format!("{}: {:.1}%", item.name, item.percentage),
                    (max_epoch * 0.8, i as f64 + 0.5),
                    ("sans-serif", 12).into_font(),
                )
            ))?;
        }

        root.present()?;
        println!("Classification results plot saved to result/classification_results.png");
    }

    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    // Create application options with a default window size
    let native_options = eframe::NativeOptions {
        viewport: eframe::egui::ViewportBuilder::default()
            .with_inner_size([800.0, 700.0]), // Make window smaller to fit all content
        ..Default::default()
    };
    
    // We need to move the app setup into the eframe creation callback
    eframe::run_native(
        "Neural Network Training (Plant Classification)",
        native_options,
        Box::new(|_cc| {
            // Create app inside the callback
            let app = NeuralNetworkApp::new();
            let app_arc = Arc::new(Mutex::new(app));
            
            // Set up training callback
            {
                let training_arc = app_arc.clone();
                
                let mut locked_app = app_arc.lock().unwrap();
                // Now accepts epochs, hidden_size, and file_path parameters
                locked_app.handle_train_click(move |epochs, hidden_size, file_path| {
                    let app_training = training_arc.clone();
                    
                    // Run training in a separate thread with customizable parameters
                    thread::spawn(move || {
                        // Use a smaller learning rate for better convergence with more epochs
                        let learning_rate = if epochs > 5000 { 0.005 } else { 0.01 };
                        
                        if let Err(e) = train_neural_network(app_training.clone(), epochs, hidden_size, learning_rate, file_path) {
                            eprintln!("Training error: {}", e);
                            // Display the error in the UI
                            app_training.lock().unwrap().set_error(e.to_string());
                        }
                    });
                });
            }
            
            Box::new(AppWrapper(app_arc))
        }),
    )?;
    
    Ok(())
}
