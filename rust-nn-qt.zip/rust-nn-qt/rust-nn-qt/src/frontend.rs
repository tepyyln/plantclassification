use eframe::egui;
use egui_plot::{Plot, Line, PlotPoints};
use std::sync::{Arc, Mutex};
use std::process::Command;

// Function to open files with default application
fn open_file(path: &str) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        let path = Path::new(path).canonicalize().map_err(|e| e.to_string())?;
        Command::new("cmd")
            .args(["/C", "start", "", path.to_str().unwrap_or(path.to_string_lossy().as_ref())])
            .spawn()
            .map_err(|e| e.to_string())?;
    }
    
    #[cfg(target_os = "macos")]
    {
        Command::new("open")
            .arg(path)
            .spawn()
            .map_err(|e| e.to_string())?;
    }
    
    #[cfg(target_os = "linux")]
    {
        Command::new("xdg-open")
            .arg(path)
            .spawn()
            .map_err(|e| e.to_string())?;
    }
    
    Ok(())
}

pub struct NeuralNetworkApp {
    progress: f32,
    current_epoch: usize,
    total_epochs: usize,
    loss: f64,
    accuracy: f64,
    is_training: bool,
    is_complete: bool,
    error_message: Option<String>,
    train_callback: Option<Box<dyn Fn(usize, usize, String) + Send + 'static>>,
    // Add history for graphs
    loss_history: Vec<(f64, f64)>,     // (epoch, loss)
    accuracy_history: Vec<(f64, f64)>, // (epoch, accuracy)
    // Add test metrics history
    test_loss_history: Vec<(f64, f64)>,     // (epoch, test_loss)
    test_accuracy_history: Vec<(f64, f64)>, // (epoch, test_accuracy)
    // Training parameters that can be adjusted in the UI
    epochs_setting: usize,
    hidden_neurons_setting: usize,
    // Additional info for architecture visualization
    input_features: usize,
    output_classes: usize, 
    show_architecture: bool,
    // Store the names of all classes
    class_names: Vec<String>,
    // Store the current prediction
    predicted_class: String,
    // Add a new field to store prediction history
    prediction_history: Vec<String>,
    // Add field for selected datasheet file
    selected_file: Option<String>,
    default_file: String,
}

// Create a wrapper type that we can implement App for
pub struct AppWrapper(pub Arc<Mutex<NeuralNetworkApp>>);

impl Clone for NeuralNetworkApp {
    fn clone(&self) -> Self {
        // We can't clone the callback, so we create a new one without it
        NeuralNetworkApp {
            progress: self.progress,
            current_epoch: self.current_epoch,
            total_epochs: self.total_epochs,
            loss: self.loss,
            accuracy: self.accuracy,
            is_training: self.is_training, 
            is_complete: self.is_complete,
            error_message: self.error_message.clone(),
            train_callback: None,
            loss_history: self.loss_history.clone(),
            accuracy_history: self.accuracy_history.clone(),
            test_loss_history: self.test_loss_history.clone(),
            test_accuracy_history: self.test_accuracy_history.clone(),
            epochs_setting: self.epochs_setting,
            hidden_neurons_setting: self.hidden_neurons_setting,
            input_features: self.input_features,
            output_classes: self.output_classes,
            show_architecture: self.show_architecture,
            class_names: self.class_names.clone(),
            predicted_class: self.predicted_class.clone(),
            prediction_history: self.prediction_history.clone(),
            selected_file: self.selected_file.clone(),
            default_file: self.default_file.clone(),
        }
    }
}

impl NeuralNetworkApp {
    pub fn new() -> Self {
        NeuralNetworkApp {
            progress: 0.0,
            current_epoch: 0,
            total_epochs: 0,
            loss: 0.0,
            accuracy: 0.0,
            is_training: false,
            is_complete: false,
            error_message: None,
            train_callback: None,
            loss_history: Vec::new(),
            accuracy_history: Vec::new(),
            test_loss_history: Vec::new(),
            test_accuracy_history: Vec::new(),
            epochs_setting: 3000,             // Higher default value for more training
            hidden_neurons_setting: 128,      // Increased hidden neurons for better learning
            input_features: 7,                // Default for Crop dataset
            output_classes: 1,                // Single output for binary classification
            show_architecture: false,         // Toggle for architecture view
            class_names: Vec::new(),
            predicted_class: "Unknown".to_string(),
            prediction_history: Vec::new(),
            selected_file: None,
            default_file: "csv/Crop_recommendation.csv".to_string(),
        }
    }

    pub fn update_progress(&mut self, epoch: usize, loss: f64, accuracy: f64) {
        self.current_epoch = epoch;
        self.loss = loss;
        self.loss_history.push((epoch as f64, loss));
        
        // Always update accuracy (the check for >= 0.0 should be redundant)
        self.accuracy = accuracy;
        self.accuracy_history.push((epoch as f64, accuracy));
        
        // Print debug information to console
        println!("Update progress: epoch={}, accuracy={:.2}%, history={} points", 
            epoch, accuracy, self.accuracy_history.len());
        
        if self.total_epochs > 0 {
            self.progress = epoch as f32 / self.total_epochs as f32;
        }
    }
    
    pub fn update_progress_with_prediction(&mut self, epoch: usize, loss: f64, accuracy: f64, prediction: String) {
        // Debug print
        println!("Updating with prediction: epoch={}, accuracy={:.2}%, prediction={}", 
            epoch, accuracy, prediction);
        
        // Add the prediction to history
        self.prediction_history.push(prediction.clone());
        
        self.update_progress(epoch, loss, accuracy);
        self.predicted_class = prediction;
    }

    pub fn set_total_epochs(&mut self, epochs: usize) {
        self.total_epochs = epochs;
    }

    pub fn training_completed(&mut self, final_accuracy: f64) {
        self.is_training = false;
        self.is_complete = true;
        self.progress = 1.0;
        self.accuracy = final_accuracy;
    }
    
    pub fn training_completed_with_prediction(&mut self, final_accuracy: f64, prediction: String) {
        self.training_completed(final_accuracy);
        self.predicted_class = prediction;
    }
    
    pub fn set_error(&mut self, error: String) {
        self.is_training = false;
        self.error_message = Some(error);
    }
    
    pub fn set_dataset_info(&mut self, input_features: usize, output_classes: usize) {
        self.input_features = input_features;
        self.output_classes = output_classes;
    }
    
    pub fn set_class_names(&mut self, class_names: Vec<String>) {
        self.class_names = class_names;
    }

    pub fn handle_train_click<F>(&mut self, callback: F)
    where
        F: Fn(usize, usize, String) + Send + 'static,  // Modified to include file path
    {
        self.train_callback = Some(Box::new(callback));
    }

    pub fn start_training(&mut self) {
        if !self.is_training && self.train_callback.is_some() {
            // Reset all state for a fresh training run
            self.is_training = true;
            self.is_complete = false;
            self.error_message = None;
            self.progress = 0.0;
            self.current_epoch = 0;
            self.loss = 0.0;
            self.accuracy = 0.0;
            self.predicted_class = "Unknown".to_string();
            
            // Clear previous training history
            self.loss_history.clear();
            self.accuracy_history.clear();
            
            println!("Starting new training run, cleared history.");
            
            if let Some(callback) = &self.train_callback {
                // Get the file path to use
                let file_path = self.selected_file.as_ref().unwrap_or(&self.default_file).clone();
                // Pass parameters to callback including the file path
                callback(self.epochs_setting, self.hidden_neurons_setting, file_path);
            }
        }
    }
    
    fn show_settings_ui(&mut self, ui: &mut egui::Ui) {
        ui.heading("Training Settings");
        
        ui.add_space(10.0);
        
        // Add file selection UI
        ui.group(|ui| {
            ui.heading("Dataset Selection");
            ui.horizontal(|ui| {
                ui.label("Current dataset:");
                ui.label(self.selected_file.as_ref().unwrap_or(&self.default_file));
            });
            
            if ui.button("Select Dataset File").clicked() {
                if let Some(path) = rfd::FileDialog::new()
                    .add_filter("CSV Files", &["csv"])
                    .set_directory(std::env::current_dir().unwrap_or_default())
                    .pick_file()
                {
                    self.selected_file = Some(path.to_string_lossy().to_string());
                }
            }
            
            if ui.button("Reset to Default Dataset").clicked() {
                self.selected_file = None;
            }
        });
        
        ui.add_space(10.0);
        
        // Number of epochs slider - increase max to 8000
        ui.horizontal(|ui| {
            ui.label("Epochs:");
            ui.add(egui::Slider::new(&mut self.epochs_setting, 100..=8000)
                .step_by(100.0)
                .suffix(" epochs"));
        });
        
        // Hidden layer neurons slider
        ui.horizontal(|ui| {
            ui.label("Hidden Neurons:");
            ui.add(egui::Slider::new(&mut self.hidden_neurons_setting, 8..=256)
                .step_by(8.0)
                .suffix(" neurons"));
        });
        
        ui.add_space(5.0);
    }
    
    fn draw_loss_graph(&self, ui: &mut egui::Ui) {
        if self.loss_history.is_empty() {
            return;
        }
        
        // Convert Vec<(f64, f64)> to Vec<[f64; 2]> for PlotPoints
        let points: Vec<[f64; 2]> = self.loss_history.iter()
            .map(|&(x, y)| [x, y])
            .collect();
            
        let line = Line::new(PlotPoints::from(points))
            .name("Loss")
            .color(egui::Color32::RED);
            
        Plot::new("loss_plot")
            .height(120.0)
            .width(ui.available_width())
            .view_aspect(3.0)
            .include_y(0.0)
            .show_axes([false, true])
            .show_x(false)
            .set_margin_fraction(egui::Vec2::new(0.0, 0.1))
            .legend(egui_plot::Legend::default())
            .show(ui, |plot_ui| {
                plot_ui.line(line);
            });
    }
    
    fn draw_accuracy_graph(&self, ui: &mut egui::Ui) {
        // Increase height for better visibility
        let height = 140.0;
        
        if self.accuracy_history.is_empty() {
            // Show empty plot with a message if no data
            Plot::new("accuracy_plot_empty")
                .height(height)
                .width(ui.available_width())
                .view_aspect(3.0)
                .include_y(0.0)
                .include_x(0.0)
                .include_y(100.0)
                .include_x(self.total_epochs as f64)
                .show_axes([true, true])
                .set_margin_fraction(egui::Vec2::new(0.0, 0.1))
                .show(ui, |plot_ui| {
                    // Add "No data" text in the center of the plot
                    plot_ui.text(egui_plot::Text::new(
                        egui_plot::PlotPoint::new(self.total_epochs as f64 / 2.0, 50.0),
                        "No accuracy data yet",
                    ));
                });
            return;
        }
        
        // Convert Vec<(f64, f64)> to Vec<[f64; 2]> for PlotPoints
        let points: Vec<[f64; 2]> = self.accuracy_history.iter()
            .map(|&(x, y)| [x, y])
            .collect();
            
        let line = Line::new(PlotPoints::from(points))
            .name("Accuracy %")
            .color(egui::Color32::GREEN)
            .width(2.0); // Make line thicker for better visibility
            
        // Get the min and max values for better scaling
        let x_max = self.total_epochs as f64;
        let mut y_max = 100.0; // Default to 100% as max
        
        // Find current max accuracy to adjust scale dynamically
        if let Some(max_acc) = self.accuracy_history.iter().map(|&(_, y)| y).fold(None, |max, x| {
            match max {
                None => Some(x),
                Some(y) => Some(x.max(y)),
            }
        }) {
            // Add 10% margin to max value, but cap at 100
            y_max = (max_acc * 1.1).min(100.0);
        }
        
        // For debugging
        ui.label(format!("Data points: {}, Last accuracy: {:.2}%", 
                       self.accuracy_history.len(),
                       self.accuracy_history.last().map_or(0.0, |&(_, acc)| acc)));
            
        Plot::new("accuracy_plot")
            .height(height)
            .width(ui.available_width())
            .view_aspect(3.0)
            .include_y(0.0)
            .include_y(y_max.max(10.0)) // Ensure a minimum range
            .include_x(0.0)
            .include_x(x_max)
            .auto_bounds_x() // Let x axis adjust
            .auto_bounds_y() // Let y axis adjust
            .show_axes([true, true]) // Show both axes
            .set_margin_fraction(egui::Vec2::new(0.0, 0.1))
            .legend(egui_plot::Legend::default())
            .show(ui, |plot_ui| {
                plot_ui.line(line);
                
                // Add current value as a point
                if let Some(&(x, y)) = self.accuracy_history.last() {
                    plot_ui.points(
                        egui_plot::Points::new(vec![[x, y]])
                            .radius(5.0)
                            .color(egui::Color32::YELLOW)
                            .name("Current")
                    );
                }
            });
    }
    
    fn draw_neural_network(&self, ui: &mut egui::Ui) {
        let available_width = ui.available_width();
        let available_height = 180.0; // Further reduce height for the visualization
        
        let (response, painter) = ui.allocate_painter(
            egui::Vec2::new(available_width, available_height),
            egui::Sense::hover(),
        );
        
        let rect = response.rect;
        
        // Drawing parameters
        let node_radius = 8.0; // Smaller nodes
        let layer_spacing = rect.width() / 4.0;
        let max_neurons_to_show = 8; // Fewer neurons to show
        
        // Draw the three layers: input, hidden, and output
        let input_layer_x = rect.left() + layer_spacing;
        let hidden_layer_x = rect.left() + 2.0 * layer_spacing;
        let output_layer_x = rect.left() + 3.0 * layer_spacing;
        
        // Calculate node positions for each layer
        let mut input_nodes = Vec::new();
        let mut hidden_nodes = Vec::new();
        let mut output_nodes = Vec::new();
        
        let input_spacing = rect.height() / (self.input_features.min(max_neurons_to_show) as f32 + 1.0);
        for i in 0..self.input_features.min(max_neurons_to_show) {
            let y = rect.top() + input_spacing * (i as f32 + 1.0);
            input_nodes.push(egui::Pos2::new(input_layer_x, y));
        }
        
        let hidden_spacing = rect.height() / (self.hidden_neurons_setting.min(max_neurons_to_show) as f32 + 1.0);
        for i in 0..self.hidden_neurons_setting.min(max_neurons_to_show) {
            let y = rect.top() + hidden_spacing * (i as f32 + 1.0);
            hidden_nodes.push(egui::Pos2::new(hidden_layer_x, y));
        }
        
        // For multiclass, the output is a vector with one node per class
        let output_spacing = rect.height() / (self.output_classes.min(max_neurons_to_show) as f32 + 1.0);
        for i in 0..self.output_classes.min(max_neurons_to_show) {
            let y = rect.top() + output_spacing * (i as f32 + 1.0);
            output_nodes.push(egui::Pos2::new(output_layer_x, y));
        }
        
        // Draw connections first (under the nodes)
        // Input to hidden
        for &input_pos in &input_nodes {
            for &hidden_pos in &hidden_nodes {
                painter.line_segment(
                    [input_pos, hidden_pos],
                    egui::Stroke::new(1.0, egui::Color32::GRAY),
                );
            }
        }
        
        // Hidden to output
        for &hidden_pos in &hidden_nodes {
            for &output_pos in &output_nodes {
                painter.line_segment(
                    [hidden_pos, output_pos],
                    egui::Stroke::new(1.0, egui::Color32::GRAY),
                );
            }
        }
        
        // Draw nodes
        for pos in &input_nodes {
            painter.circle_filled(
                *pos,
                node_radius,
                egui::Color32::BLUE,
            );
        }
        
        for pos in &hidden_nodes {
            painter.circle_filled(
                *pos,
                node_radius,
                egui::Color32::LIGHT_BLUE,
            );
        }
        
        for (i, pos) in output_nodes.iter().enumerate() {
            // Highlight the node corresponding to the predicted class
            let node_color = if i < self.class_names.len() && &self.class_names[i] == &self.predicted_class {
                egui::Color32::YELLOW
            } else {
                egui::Color32::GREEN
            };
            
            painter.circle_filled(
                *pos,
                node_radius,
                node_color,
            );
            
            // Add class labels next to output nodes if we have class names
            if i < self.class_names.len() && i < max_neurons_to_show {
                painter.text(
                    egui::Pos2::new(output_layer_x + node_radius * 2.0, pos.y),
                    egui::Align2::LEFT_CENTER,
                    &self.class_names[i],
                    egui::FontId::proportional(12.0),
                    egui::Color32::BLACK,
                );
            }
        }
        
        // Draw layer labels with smaller font
        let font_id = egui::FontId::proportional(12.0); // Smaller font
        
        painter.text(
            egui::Pos2::new(input_layer_x, rect.top() + 12.0),
            egui::Align2::CENTER_CENTER,
            format!("Input\n({} feat.)", self.input_features), // Shorter text
            font_id.clone(),
            egui::Color32::BLACK,
        );
        
        painter.text(
            egui::Pos2::new(hidden_layer_x, rect.top() + 12.0),
            egui::Align2::CENTER_CENTER,
            format!("Hidden\n({} neur.)", self.hidden_neurons_setting), // Shorter text
            font_id.clone(),
            egui::Color32::BLACK,
        );
        
        painter.text(
            egui::Pos2::new(output_layer_x, rect.top() + 12.0),
            egui::Align2::CENTER_CENTER,
            format!("Output\n({} class.)", self.output_classes), // Shorter text
            font_id.clone(),
            egui::Color32::BLACK,
        );
        
        // Display predicted class information with smaller font
        painter.text(
            egui::Pos2::new(rect.center().x, rect.bottom() - 15.0),
            egui::Align2::CENTER_CENTER,
            format!("Predicted: {}", self.predicted_class),
            egui::FontId::proportional(14.0), // Smaller font
            egui::Color32::BLACK,
        );
        
        // If we're showing limited nodes, indicate there are more
        if self.input_features > max_neurons_to_show {
            painter.text(
                egui::Pos2::new(input_layer_x, rect.bottom() - 30.0),
                egui::Align2::CENTER_CENTER,
                format!("+ {} more", self.input_features - max_neurons_to_show),
                egui::FontId::proportional(10.0),
                egui::Color32::BLACK,
            );
        }
        
        if self.hidden_neurons_setting > max_neurons_to_show {
            painter.text(
                egui::Pos2::new(hidden_layer_x, rect.bottom() - 30.0),
                egui::Align2::CENTER_CENTER,
                format!("+ {} more", self.hidden_neurons_setting - max_neurons_to_show),
                egui::FontId::proportional(10.0),
                egui::Color32::BLACK,
            );
        }
        
        if self.output_classes > max_neurons_to_show {
            painter.text(
                egui::Pos2::new(output_layer_x, rect.bottom() - 30.0),
                egui::Align2::CENTER_CENTER,
                format!("+ {} more", self.output_classes - max_neurons_to_show),
                egui::FontId::proportional(10.0),
                egui::Color32::BLACK,
            );
        }
    }

    fn draw_saved_plots(&self, ui: &mut egui::Ui) {
        if self.is_complete {
            ui.vertical_centered(|ui| {
                ui.add_space(10.0);
                ui.heading("Saved Training Results");
            });
            
            ui.label("Training plots have been saved to the result directory:");
            
            // Add a visible frame around the links section with light theme colors
            egui::Frame::group(ui.style())
                .fill(egui::Color32::from_rgb(240, 240, 250))
                .stroke(egui::Stroke::new(1.0, egui::Color32::from_rgb(200, 200, 220)))
                .show(ui, |ui| {
                    ui.add_space(10.0);
                    
                    // List the saved files with more spacing and better visibility
                    ui.horizontal(|ui| {
                        ui.label("• ");
                        let loss_link = ui.link("Loss Plot");
                        if loss_link.clicked() {
                            if let Err(e) = open_file("result/loss_plot.png") {
                                eprintln!("Error opening file: {}", e);
                            }
                        }
                        loss_link.on_hover_text("Click to open loss plot image");
                        
                        if ui.button("Open").clicked() {
                            if let Err(e) = open_file("result/loss_plot.png") {
                                eprintln!("Error opening file: {}", e);
                            }
                        }
                        
                        ui.label("- Shows how the model's error decreased during training");
                    });
                    
                    ui.add_space(5.0);
                    
                    ui.horizontal(|ui| {
                        ui.label("• ");
                        let accuracy_link = ui.link("Accuracy Plot");
                        if accuracy_link.clicked() {
                            if let Err(e) = open_file("result/accuracy_plot.png") {
                                eprintln!("Error opening file: {}", e);
                            }
                        }
                        accuracy_link.on_hover_text("Click to open accuracy plot image");
                        
                        if ui.button("Open").clicked() {
                            if let Err(e) = open_file("result/accuracy_plot.png") {
                                eprintln!("Error opening file: {}", e);
                            }
                        }
                        
                        ui.label("- Shows how classification accuracy improved (final value: ");
                        ui.colored_label(
                            if self.accuracy >= 90.0 { egui::Color32::from_rgb(50, 180, 50) }
                            else if self.accuracy >= 75.0 { egui::Color32::from_rgb(180, 180, 50) }
                            else { egui::Color32::from_rgb(180, 50, 50) },
                            format!("{:.2}%", self.accuracy)
                        );
                        ui.label(")");
                    });
                    
                    ui.add_space(5.0);
                    
                    ui.horizontal(|ui| {
                        ui.label("• ");
                        let combined_link = ui.link("Combined Training Results");
                        if combined_link.clicked() {
                            if let Err(e) = open_file("result/training_results.png") {
                                eprintln!("Error opening file: {}", e);
                            }
                        }
                        combined_link.on_hover_text("Click to open combined training results image");
                        
                        if ui.button("Open").clicked() {
                            if let Err(e) = open_file("result/training_results.png") {
                                eprintln!("Error opening file: {}", e);
                            }
                        }
                        
                        ui.label("- Shows both loss and accuracy in a single view");
                    });
                    
                    ui.add_space(5.0);
                    
                    ui.horizontal(|ui| {
                        ui.label("• ");
                        let classification_link = ui.link("Plant Classification Results");
                        if classification_link.clicked() {
                            if let Err(e) = open_file("result/classification_results.png") {
                                eprintln!("Error opening file: {}", e);
                            }
                        }
                        classification_link.on_hover_text("Click to open classification results plot");
                        
                        if ui.button("Open").clicked() {
                            if let Err(e) = open_file("result/classification_results.png") {
                                eprintln!("Error opening file: {}", e);
                            }
                        }
                        
                        ui.label("- Shows how predictions changed during training");
                    });
                    
                    ui.add_space(10.0);
                    
                    // Add summary of test results
                    ui.separator();
                    ui.add_space(5.0);
                    
                    ui.vertical_centered(|ui| {
                        ui.heading("Test Results Summary");
                    });
                    
                    ui.add_space(5.0);
                    
                    // Final accuracy summary with colored bar
                    ui.horizontal(|ui| {
                        ui.label("Final Accuracy:");
                        let progress = (self.accuracy / 100.0) as f32;
                        let color = if self.accuracy >= 90.0 {
                            egui::Color32::from_rgb(50, 180, 50) // Green
                        } else if self.accuracy >= 75.0 {
                            egui::Color32::from_rgb(180, 180, 50) // Yellow
                        } else {
                            egui::Color32::from_rgb(180, 50, 50) // Red
                        };
                        
                        ui.add(egui::ProgressBar::new(progress)
                            .fill(color)
                            .text(format!("{:.2}%", self.accuracy)));
                    });
                    
                    // Final loss value
                    ui.horizontal(|ui| {
                        ui.label("Final Loss:");
                        ui.label(format!("{:.4}", self.loss));
                    });
                    
                    // Training statistics
                    ui.add_space(5.0);
                    ui.horizontal(|ui| {
                        ui.label("Total Epochs:");
                        ui.label(format!("{}", self.current_epoch));
                    });
                    
                    ui.horizontal(|ui| {
                        ui.label("Hidden Neurons:");
                        ui.label(format!("{}", self.hidden_neurons_setting));
                    });
                    
                });
            
            ui.add_space(30.0); // Add extra space at the bottom to ensure scrolling
        }
    }

    fn draw_prediction_graph(&self, ui: &mut egui::Ui) {
        if self.prediction_history.is_empty() || self.class_names.is_empty() {
            ui.label("No prediction data available yet");
            return;
        }
        
        // Set up plot area with appropriate height
        let height = 180.0;
        
        // Create a plot showing the class predictions over time with light theme colors
        Plot::new("prediction_plot")
            .height(height)
            .width(ui.available_width())
            .view_aspect(3.0)
            .include_y(0.0)
            .include_y((self.class_names.len() as f64) + 0.5)
            .include_x(0.0)
            .include_x(self.total_epochs as f64)
            .show_axes([true, true])
            .y_axis_width(4) // Make y-axis wider for class names
            .label_formatter(|name, value| {
                // No need to use self here, so no lifetime issues
                if !name.is_empty() {
                    return format!("{}: ({:.1}, {:.1})", name, value.x, value.y);
                }
                format!("({:.1}, {:.1})", value.x, value.y)
            })
            .show(ui, |plot_ui| {
                // Clone class_names to avoid lifetime issues
                let class_names = self.class_names.clone();
                
                // Draw horizontal lines for each class with lighter colors
                for i in 0..class_names.len() {
                    plot_ui.hline(
                        egui_plot::HLine::new(i as f64 + 0.5)
                            .color(egui::Color32::from_rgba_premultiplied(220, 220, 220, 200))
                            .width(1.0)
                    );
                }
                
                // Create data points from prediction history
                let mut points = Vec::new();
                for (i, prediction) in self.prediction_history.iter().enumerate() {
                    // Calculate epoch based on prediction index and total epochs
                    let epoch = if self.total_epochs > 0 && !self.accuracy_history.is_empty() {
                        // Use actual epoch from accuracy history if available
                        if i < self.accuracy_history.len() {
                            self.accuracy_history[i].0
                        } else {
                            // Estimate epoch based on position in history
                            (i as f64 / self.prediction_history.len() as f64) * self.total_epochs as f64
                        }
                    } else {
                        i as f64 // Fallback
                    };
                    
                    // Find the class index for this prediction
                    if let Some(class_idx) = class_names.iter().position(|name| name == prediction) {
                        points.push([epoch, class_idx as f64 + 0.5]);
                    }
                }
                
                // Draw scatter plot of points
                if !points.is_empty() {
                    let plot_points = egui_plot::PlotPoints::from(points.clone());
                    
                    plot_ui.points(
                        egui_plot::Points::new(plot_points)
                            .radius(4.0)
                            .color(egui::Color32::YELLOW)
                            .shape(egui_plot::MarkerShape::Circle)
                            .name("Predictions")
                    );
                    
                    // Add the most recent point with a different color/size
                    if let Some(&[x, y]) = points.last() {
                        plot_ui.points(
                            egui_plot::Points::new(egui_plot::PlotPoints::from(vec![[x, y]]))
                                .radius(6.0)
                                .color(egui::Color32::RED)
                                .shape(egui_plot::MarkerShape::Circle)
                                .name("Current")
                        );
                    }
                }
                
                // Draw y-axis labels (class names) with dark text for light theme
                for (i, class_name) in class_names.iter().enumerate() {
                    plot_ui.text(
                        egui_plot::Text::new(
                            egui_plot::PlotPoint::new(-0.05 * self.total_epochs as f64, i as f64 + 0.5),
                            class_name.clone()
                        )
                        .color(egui::Color32::DARK_GRAY)
                        .anchor(egui::Align2::RIGHT_CENTER)
                    );
                }
            });
    }

    // Add a method to update test metrics
    pub fn update_test_metrics(&mut self, epoch: usize, test_loss: f64, test_accuracy: f64) {
        self.test_loss_history.push((epoch as f64, test_loss));
        self.test_accuracy_history.push((epoch as f64, test_accuracy));
        
        // Print debug information to console
        println!("Update test metrics: epoch={}, test_loss={:.5}, test_accuracy={:.2}%", 
            epoch, test_loss, test_accuracy);
    }

    // Add methods to draw test metrics graphs
    fn draw_test_loss_graph(&self, ui: &mut egui::Ui) {
        if self.test_loss_history.is_empty() {
            ui.label("No test loss data available yet");
            return;
        }
        
        // Convert Vec<(f64, f64)> to Vec<[f64; 2]> for PlotPoints
        let points: Vec<[f64; 2]> = self.test_loss_history.iter()
            .map(|&(x, y)| [x, y])
            .collect();
            
        let line = Line::new(PlotPoints::from(points))
            .name("Test Loss")
            .color(egui::Color32::from_rgb(220, 60, 60))
            .width(2.0);
            
        Plot::new("test_loss_plot")
            .height(120.0)
            .width(ui.available_width())
            .view_aspect(3.0)
            .include_y(0.0)
            .show_axes([false, true])
            .show_x(false)
            .set_margin_fraction(egui::Vec2::new(0.0, 0.1))
            .legend(egui_plot::Legend::default())
            .show(ui, |plot_ui| {
                plot_ui.line(line);
                
                // Show last test loss value with detailed decimal format
                if let Some(&(x, y)) = self.test_loss_history.last() {
                    // Add a label with decimal precision
                    plot_ui.text(
                        egui_plot::Text::new(
                            egui_plot::PlotPoint::new(x, y),
                            format!("{:.5}", y)
                        )
                        .color(egui::Color32::WHITE)
                        .anchor(egui::Align2::RIGHT_BOTTOM)
                    );
                }
            });
    }

    fn draw_test_accuracy_graph(&self, ui: &mut egui::Ui) {
        if self.test_accuracy_history.is_empty() {
            ui.label("No test accuracy data available yet");
            return;
        }
        
        // Convert Vec<(f64, f64)> to Vec<[f64; 2]> for PlotPoints
        let points: Vec<[f64; 2]> = self.test_accuracy_history.iter()
            .map(|&(x, y)| [x, y])
            .collect();
            
        let line = Line::new(PlotPoints::from(points))
            .name("Test Accuracy %")
            .color(egui::Color32::from_rgb(100, 180, 60))
            .width(2.0);
            
        let test_accuracy = self.test_accuracy_history.last().map(|&(_, acc)| acc).unwrap_or(0.0);
        
        Plot::new("test_accuracy_plot")
            .height(140.0)
            .width(ui.available_width())
            .view_aspect(3.0)
            .include_y(0.0)
            .include_y(100.0)
            .show_axes([true, true])
            .set_margin_fraction(egui::Vec2::new(0.0, 0.1))
            .legend(egui_plot::Legend::default())
            .show(ui, |plot_ui| {
                plot_ui.line(line);
                
                // Add threshold lines
                plot_ui.hline(
                    egui_plot::HLine::new(95.0)
                        .color(egui::Color32::from_rgba_premultiplied(50, 200, 50, 100))
                        .width(1.0)
                        .name("Excellent (95%)")
                );
                
                plot_ui.hline(
                    egui_plot::HLine::new(90.0)
                        .color(egui::Color32::from_rgba_premultiplied(200, 200, 50, 100))
                        .width(1.0)
                        .name("Very Good (90%)")
                );
                
                // Add current value as a point
                if let Some(&(x, y)) = self.test_accuracy_history.last() {
                    plot_ui.points(
                        egui_plot::Points::new(vec![[x, y]])
                            .radius(5.0)
                            .color(egui::Color32::YELLOW)
                            .name(format!("Current: {:.2}%", y))
                    );
                    
                    // Add rating text
                    let rating = if y >= 95.0 {
                        "Excellent"
                    } else if y >= 90.0 {
                        "Very Good"
                    } else if y >= 85.0 {
                        "Good"
                    } else if y >= 75.0 {
                        "Fair"
                    } else {
                        "Needs Improvement"
                    };
                    
                    plot_ui.text(
                        egui_plot::Text::new(
                            egui_plot::PlotPoint::new(x, y + 3.0),
                            format!("{:.2}% ({})", y, rating)
                        )
                        .color(egui::Color32::YELLOW)
                        .anchor(egui::Align2::CENTER_BOTTOM)
                    );
                }
            });
            
        // Show current test accuracy as text with color coding
        let color = if test_accuracy >= 95.0 {
            egui::Color32::from_rgb(50, 200, 50) // Green for excellent
        } else if test_accuracy >= 90.0 {
            egui::Color32::from_rgb(150, 200, 50) // Yellow-green for very good
        } else if test_accuracy >= 85.0 {
            egui::Color32::from_rgb(200, 200, 50) // Yellow for good
        } else {
            egui::Color32::from_rgb(200, 100, 50) // Orange for needs improvement
        };
        
        ui.colored_label(color, format!("Test Accuracy: {:.2}%", test_accuracy));
    }
}

impl eframe::App for NeuralNetworkApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // Set the visuals to a light theme
        ctx.set_visuals(egui::Visuals::light());
        
        // Make the central panel scrollable
        egui::CentralPanel::default().show(ctx, |ui| {
            egui::ScrollArea::vertical().show(ui, |ui| {
                ui.heading("Plant Classification Neural Network");
                
                ui.add_space(5.0); // Reduce spacing

                // Use horizontal layout for settings and status to save vertical space
                ui.horizontal_wrapped(|ui| {
                    // Left side: settings
                    ui.vertical(|ui| {
                        ui.group(|ui| {
                            // Only show settings if not training
                            if !self.is_training {
                                self.show_settings_ui(ui);
                            }
                            // Always show architecture checkbox regardless of training state
                            ui.checkbox(&mut self.show_architecture, "Show Network Architecture");
                        });
                    });
                    
                    // Right side: training status
                    ui.vertical(|ui| {
                        // Training controls
                        ui.horizontal(|ui| {
                            if ui.button("Start Training").clicked() && !self.is_training {
                                self.start_training();
                            }

                            if self.is_complete {
                                ui.label(format!("Training complete! Accuracy: {:.2}%", self.accuracy));
                            } else if self.is_training {
                                ui.spinner();
                                ui.label("Training in progress...");
                            }
                        });
                        
                        // Display current prediction prominently
                        if !self.predicted_class.is_empty() && self.predicted_class != "Unknown" {
                            ui.add_space(5.0);
                            ui.horizontal(|ui| {
                                ui.label("Prediction:");
                                ui.colored_label(egui::Color32::YELLOW, &self.predicted_class);
                            });
                        }
                        
                        // Error message
                        if let Some(error) = &self.error_message {
                            ui.add_space(5.0);
                            ui.colored_label(egui::Color32::RED, format!("Error: {}", error));
                        }
                        
                        ui.add_space(5.0);
                        
                        // Progress bar and epoch counter
                        ui.label(format!("Epoch: {}/{}", self.current_epoch, self.total_epochs));
                        ui.add(egui::ProgressBar::new(self.progress)
                            .show_percentage()
                            .animate(self.is_training));
                        
                        // Training stats
                        if self.current_epoch > 0 {
                            ui.horizontal(|ui| {
                                ui.label(format!("Loss: {:.4}", self.loss));
                                if self.accuracy > 0.0 {
                                    ui.label(format!("Accuracy: {:.2}%", self.accuracy));
                                }
                            });
                        }
                    });
                });
                
                // Show architecture if enabled
                if self.show_architecture {
                    ui.add_space(5.0);
                    ui.group(|ui| {
                        ui.heading("Network Architecture");
                        self.draw_neural_network(ui);
                    });
                }
                
                // Enhanced test results section - show when we have predictions
                if !self.prediction_history.is_empty() {
                    ui.add_space(10.0);
                    ui.vertical_centered(|ui| {
                        ui.heading("Training & Test Results");
                    });
                    
                    // Add Test Metrics section
                    if !self.test_loss_history.is_empty() {
                        ui.add_space(5.0);
                        ui.group(|ui| {
                            ui.heading("Test Loss (Decimal Format)");
                            self.draw_test_loss_graph(ui);
                        });
                        
                        ui.add_space(5.0);
                        ui.group(|ui| {
                            ui.heading("Test Accuracy (%)");
                            self.draw_test_accuracy_graph(ui);
                        });
                    }
                    
                    // Always show the prediction timeline
                    ui.group(|ui| {
                        ui.heading("Prediction Timeline");
                        self.draw_prediction_graph(ui);
                    });
                    
                    // Add statistics section for test results
                    ui.add_space(5.0);
                    ui.group(|ui| {
                        ui.heading("Test Results Summary");
                        
                        if self.is_complete {
                            // Display final performance metrics
                            ui.horizontal(|ui| {
                                ui.strong("Final Accuracy:");
                                ui.label(format!("{:.2}%", self.accuracy));
                                
                                // Add color indicator based on accuracy
                                let color = if self.accuracy >= 90.0 {
                                    egui::Color32::from_rgb(50, 180, 50) // Green for good
                                } else if self.accuracy >= 75.0 {
                                    egui::Color32::from_rgb(180, 180, 50) // Yellow for okay
                                } else {
                                    egui::Color32::from_rgb(180, 50, 50) // Red for poor
                                };
                                
                                ui.colored_label(color, format!("({})", 
                                    if self.accuracy >= 90.0 { "Excellent" }
                                    else if self.accuracy >= 75.0 { "Good" }
                                    else { "Needs improvement" }
                                ));
                            });
                            
                            ui.horizontal(|ui| {
                                ui.strong("Final Loss:");
                                ui.label(format!("{:.5}", self.loss));
                            });
                            
                            // Show test accuracy if available
                            if !self.test_accuracy_history.is_empty() {
                                if let Some(&(_, test_accuracy)) = self.test_accuracy_history.last() {
                                    ui.horizontal(|ui| {
                                        ui.strong("Test Accuracy:");
                                        
                                        // Color code the test accuracy
                                        let color = if test_accuracy >= 95.0 {
                                            egui::Color32::from_rgb(50, 200, 50) // Green for excellent
                                        } else if test_accuracy >= 90.0 {
                                            egui::Color32::from_rgb(150, 200, 50) // Yellow-green for very good
                                        } else if test_accuracy >= 85.0 {
                                            egui::Color32::from_rgb(200, 200, 50) // Yellow for good
                                        } else {
                                            egui::Color32::from_rgb(200, 100, 50) // Orange for needs improvement
                                        };
                                        
                                        ui.colored_label(color, format!("{:.2}%", test_accuracy));
                                        
                                        // Add rating
                                        let rating = if test_accuracy >= 95.0 {
                                            "Excellent"
                                        } else if test_accuracy >= 90.0 {
                                            "Very Good"
                                        } else if test_accuracy >= 85.0 {
                                            "Good"
                                        } else if test_accuracy >= 75.0 {
                                            "Fair"
                                        } else {
                                            "Needs Improvement"
                                        };
                                        
                                        ui.label(format!("({})", rating));
                                    });
                                }
                            }
                            
                            // Show test loss if available
                            if !self.test_loss_history.is_empty() {
                                if let Some(&(_, test_loss)) = self.test_loss_history.last() {
                                    ui.horizontal(|ui| {
                                        ui.strong("Test Loss:");
                                        ui.label(format!("{:.5}", test_loss));
                                    });
                                }
                            }
                            
                            // Add confusion matrix stats if complete
                            if let Some(last_prediction) = self.prediction_history.last() {
                                ui.add_space(5.0);
                                ui.horizontal(|ui| {
                                    ui.strong("Final prediction:");
                                    ui.colored_label(egui::Color32::from_rgb(30, 100, 200), last_prediction);
                                });
                                
                                // Count class distributions in predictions
                                let mut class_counts = std::collections::HashMap::new();
                                for prediction in &self.prediction_history {
                                    *class_counts.entry(prediction).or_insert(0) += 1;
                                }
                                
                                ui.add_space(5.0);
                                ui.label("Prediction distribution during training:");
                                
                                // Display class prediction distributions
                                for (class_name, count) in class_counts.iter() {
                                    let percentage = (*count as f32 / self.prediction_history.len() as f32) * 100.0;
                                    
                                    ui.horizontal(|ui| {
                                        ui.label(format!("• {}:", class_name));
                                        ui.add(egui::ProgressBar::new(percentage / 100.0)
                                            .text(format!("{:.1}%", percentage)));
                                    });
                                }
                            }
                        } else {
                            // Show in-progress metrics
                            ui.label("Training in progress... Final results will appear here.");
                            
                            if let Some(last_prediction) = self.prediction_history.last() {
                                ui.horizontal(|ui| {
                                    ui.strong("Current prediction:");
                                    ui.label(last_prediction);
                                });
                            }
                            
                            ui.horizontal(|ui| {
                                ui.strong("Current accuracy:");
                                ui.label(format!("{:.2}%", self.accuracy));
                            });
                        }
                    });
                }
                
                // Always show accuracy graph even if empty
                ui.add_space(5.0);
                
                // Always show accuracy graph
                ui.group(|ui| {
                    ui.heading("Training Accuracy (%)");
                    self.draw_accuracy_graph(ui);
                });
                
                // Only show the loss graph if we have data
                if !self.loss_history.is_empty() {
                    ui.add_space(5.0);
                    ui.group(|ui| {
                        ui.heading("Training Loss");
                        self.draw_loss_graph(ui);
                    });
                }
                
                // Add section for saved plots if training is complete
                if self.is_complete {
                    ui.add_space(20.0);
                    ui.separator();
                    self.draw_saved_plots(ui);
                }
            });
            
            // Force a repaint to keep UI updating during training
            if self.is_training {
                ctx.request_repaint();
            }
        });
    }
}

// Implement App for our wrapper type
impl eframe::App for AppWrapper {
    fn update(&mut self, ctx: &egui::Context, frame: &mut eframe::Frame) {
        // Apply light theme styling
        ctx.set_visuals(egui::Visuals::light());
        
        // Force a repaint every frame when training to ensure UI stays updated
        let is_training = self.0.lock().unwrap().is_training;
        if is_training {
            ctx.request_repaint(); // Request a repaint every frame during training
        }
        
        // Acquire the lock and update the inner app
        if let Ok(mut app) = self.0.lock() {
            app.update(ctx, frame);
        }
    }
} 